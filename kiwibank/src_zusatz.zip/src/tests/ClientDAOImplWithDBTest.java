package tests;

import java.time.LocalDate;

import de.kiwi.backend.Client;
import de.kiwi.backend.ClientDAOImplWithDB;

public class ClientDAOImplWithDBTest {

	public static void main(String[] args) {


		ClientDAOImplWithDB allClients = new ClientDAOImplWithDB();
		
//		Client kunden = new Client();
//		System.out.println(kunden);
//		
		Client kunden3 = new Client("Cony Con", LocalDate.of(2005,04,21), 222222222, 7000, 7777);
//		System.out.println(kunden2);
//		kunden2.setPrimaryKey(4322);
		
		//allClients.addClient(kunden2);
		
		//allClients.updateClient(kunden2);
		
//		allClients.addClient(kunden2);
//		System.out.println("----------geschrieben--------------");
		System.out.println(allClients.getAllClients());
		
		System.out.println("***************************");
		
		allClients.getAllClients().forEach(eve->System.out.println(eve));
		
		//allClients.deleteClient(kunden2);
		
		System.out.println("***** Update ******");
		
		allClients.updateClient(kunden3);
		
		allClients.getAllClients().forEach(eve->System.out.println(eve));
		
		
	}

}
