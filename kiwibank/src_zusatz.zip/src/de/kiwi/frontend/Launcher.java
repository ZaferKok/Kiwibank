package de.kiwi.frontend;

import javafx.application.Application;

/** This is the class to activate the application. */

public class Launcher {

	public static void main(String[] args) {

		Application.launch(de.kiwi.frontend.KiwiBankApp.class);
			
	}
}
