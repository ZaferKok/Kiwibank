package de.kiwi.middle.methods;

/** If user types out of numberd into the boxes, 
 *  which need only numbers, it throws this Exception */

public class LetterTypeInsteadOfNumberException extends Exception {

}
